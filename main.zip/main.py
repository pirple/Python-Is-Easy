"""
HOMEWORK #1 : VARIABLES

ATTRIBUTES OF MY FAVORITE SONG
"""

#Name of Artist
Artist = "Soundgarden"

#Music Genre
Genre = "Grunge"

#Song Duration
DurationInSeconds = 328

#Year of song release
YearReleased = "May 13, 1994"

#Year the song was recorded
YearRecorded = "July - September, 1993"


print(Artist)
print(Genre)
print(DurationInSeconds)
print(YearReleased)
print(YearRecorded)